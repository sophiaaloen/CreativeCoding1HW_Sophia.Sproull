function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  rect(150,275,100,150)
  circle(200,175,250)
  triangle(317,217,322,150,345,205)
  circle(317,212,15)
  ellipse(202,175,30,50)
  circle(208,175,10)
  line(205,162,208,167)
  line(195,165,205,162)
  line(203,187,199,185)
  line(199,185,195,165)
  point(205,194)
  ellipse(300,150,40,25)
  circle(305,148,20)
  line(270,245,301,250)
  line(265,240,270,245)
  line(275,130,320,130)
  textSize(32)
  text('Self-Portrait',125,30)
  textSize(10)
  text('Sophie Sproull',300,375)
}