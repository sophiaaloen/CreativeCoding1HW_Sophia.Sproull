setProperty("text_area1", "text-color", "white");
setProperty("text_area1", "font-size", 24);
setProperty("text_area1", "background-color", "#000000");
setProperty("screen01", "background-color", "#000000");
onEvent("button1", "click", function( ) {
  setScreen("screen02");
});
onEvent("button2", "click", function( ) {
  setScreen("screen03");
  setProperty("screen03", "background-color", "red");
});
onEvent("button3", "click", function( ) {
  setScreen("screen03");
  setProperty("screen03", "background-color", "green");
});
onEvent("button4", "click", function( ) {
  setScreen("screen04");
});
onEvent("button5", "click", function( ) {
  setScreen("screen05");
  setProperty("screen05", "background-color", "green");
});
onEvent("button6", "click", function( ) {
  setScreen("screen05");
  setProperty("screen05", "background-color", "red");
});
onEvent("button16", "click", function( ) {
  setScreen("screen06");
});
onEvent("button8", "click", function( ) {
  setScreen("screen07");
  setProperty("screen07", "background-color", "green");
});
onEvent("button9", "click", function( ) {
  setScreen("screen07");
  setProperty("screen07", "background-color", "red");
});
onEvent("button17", "click", function( ) {
  setScreen("screen08");
});
onEvent("button12", "click", function( ) {
  setScreen("screen09");
  setProperty("screen09", "background-color", "red");
});
onEvent("button13", "click", function( ) {
  setScreen("screen09");
  setProperty("screen09", "background-color", "green");
});
onEvent("button18", "click", function( ) {
  setScreen("screen10");
});
onEvent("button14", "click", function( ) {
  setScreen("screen11");
  setProperty("screen11", "background-color", "green");
});
onEvent("button15", "click", function( ) {
  setScreen("screen11");
  setProperty("screen11", "background-color", "red");
});
onEvent("button19", "click", function( ) {
  setScreen("screen12");
});
